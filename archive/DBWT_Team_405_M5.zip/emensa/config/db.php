<?php
return [
    'host' => 'localhost',  // 'localhost' or '127.0.0.1'
    'user' => 'root',       // '<yourusername>'
    'password' => 'root', // '<yourpassword>'
    'database' => 'emensawerbeseite',
    // optionally: set port below if it differs from the default 3306
    'port' => 8000,
];
