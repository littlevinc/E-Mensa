<?php

echo "sha1 Hash für PW \"lbkfadminpass\": ".sha1("lbkfadminpass");