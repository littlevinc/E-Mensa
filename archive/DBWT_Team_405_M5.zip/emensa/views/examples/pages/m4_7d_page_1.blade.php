@extends("examples.layouts.m4layout")

@section('title', 'Page 1')

@section('header')
    <h1>PAGE 1</h1>
@endsection

@section('main')
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequuntur ducimus eligendi exercitationem iusto, magnam molestias non nostrum reprehenderit sed ullam veritatis voluptatum? Aspernatur ex facilis neque numquam odit sint voluptates?</p>
@endsection

@section('footer')
    <p>Thanks for visiting page 1</p>
@endsection
