@extends("examples.layouts.m4layout")

@section('title', 'Page 2')

@section('header')
    <h1>PAGE 2</h1>
@endsection

@section('main')
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequuntur ducimus eligendi exercitationem iusto, magnam molestias non nostrum reprehenderit sed ullam veritatis voluptatum? Aspernatur ex facilis neque numquam odit sint voluptates?</p>

@endsection

@section('footer')
    <p>Thanks for visiting page 2</p>
@endsection
